## Tmon Elastic Search Database Log Analyzing and Error Notifying Web App

Tmon의 elastic search의 로그를 분석해서 일정 이상의 abnormally 발견 시 push를 
주는 application 입니다.

### Structure
* Backend
    1. structure
    <pre>  
        --+config       es 접속에 필요한 client생성을 위한 configuration
        --+controller   controller
        --+model        데이터를 담기 위한 model
        --+repository   repository - es와 직접 데이터를 주고받음
        --+schedule     batch실행을 위한 job을 담는 class
        --+service      service
        --+utility      jandi or es query 생성에 도움을 주는 static method
        +StartUp        Startup시 실행되는 루틴을 위한 class
    </pre>
    
* [Not applied] Frontend
    1. structure 
    <pre>
        --+information
        ----+introduction
        ----+concept
        ----+contact
        --+notification
        --+visualization
    </pre>
### Concept

* Backend
    1. startup시 threshold를 계산해서 json파일로 저장
    2. 10분 당 한번 abnormally에 대해 검사
    3. 2시간 당 한번 threshold 재설정
    
* [Not applied] Frontend
    1. information
    2. google chart 이용. 5초당 draw하는 그래프 생성
    3. 현재 notification 상황을 보여줌

#### Error Notifying Threshold 
* Tomcat log - avg count's 200%
* Reponse time - 0.1ms(fixed)
* [Not applied] access count - above top 20%

### Function

### Usage
