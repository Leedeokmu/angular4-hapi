package com.esnotify.dto;

/*
* Elastic Search engine에 들어갈
* 쿼리의 일부 정보를 담는 parameter model
*
* serviceName : 매치할 서비스 이름
* index : 검색할 index 이름
* range : range 검색 시 사용되는 범위(now() ~ from)
* */
public class ESQueryParams {
    private String serviceName;
    private String index;
    private long range;

    public ESQueryParams(String index,String serviceName, long range) {
        this.index = index;
        this.serviceName = serviceName;
        this.range = range;
    }

    public void setEsQueryParams(String index, String serviceName, long range) {
        this.index = index;
        this.serviceName = serviceName;
        this.range = range;
    }

    public String getServiceName() {
        return serviceName;
    }

    public String getIndex() {
        return index;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public long getRange() { return range; }

    public void setRange(long range) { this.range = range; }
}