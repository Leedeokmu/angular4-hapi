package com.esnotify.dto;

/*
* jandi 메신져 바디 내에 들어가는
* connctInfo 부분을 구성하는 message 모델
* */
public class JandiMessage {
    private String title;
    private String description;

    public JandiMessage(String title, String description) {
        this.title = title;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }
}
