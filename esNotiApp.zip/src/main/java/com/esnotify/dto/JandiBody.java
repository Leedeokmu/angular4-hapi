package com.esnotify.dto;

import java.util.ArrayList;

/*
* Jandi 메신져의 webhook 기능을 이용할 때
* 바디를 구성하기 위한 모델
* */
public class JandiBody {
    private String body;
    private String connectColor;
    private ArrayList<JandiMessage> connectInfo;

    public JandiBody() {
        this.connectInfo = new ArrayList<>();
    }

    public String getBody() {
        return body;
    }

    public JandiBody setBody(String body, String url, String text) {
        this.body = "[[" + body + "]](" + url + ") " + text;
        return this;
    }

    public String getConnectColor() {
        return connectColor;
    }

    public JandiBody setConnectColor(String connectColor) {
        this.connectColor = connectColor;
        return this;
    }
    public void setBody(String body) {
        this.body = body;
    }

    public ArrayList<JandiMessage> getConnectInfo() {
        return connectInfo;
    }

    public void setConnectInfo(ArrayList<JandiMessage> connectInfo) {
        this.connectInfo = connectInfo;
    }
    public void addConnectInfo(JandiMessage jandiMessage){
        this.connectInfo.add(jandiMessage);
    }
}
