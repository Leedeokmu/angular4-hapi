package com.esnotify.utility;

import com.esnotify.dto.JandiBody;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.esnotify.dto.JandiMessage;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;


/**
 * Created by freefly3557 on 2017-07-14.
 */
public class JandiMsgSenderUtil {

    private String apiUrl;
    private ObjectMapper objectMapper;
    private RestTemplate restTemplate;

    public JandiMsgSenderUtil(String apiUrl){
        this.apiUrl = apiUrl;
        restTemplate = new RestTemplate();
        objectMapper = new ObjectMapper();
    }
    /* 등록된 특정 JandiBody webhook 주소를 받아와서
    *  message를 전송하도록 http header를 구성하고
    *  body를 전송합니다
    *
    *  JandiBody message body 생성 및 내용 입력->
    *  specific header value setting ->
    *  send with restTemplate(responseEntity)
    *
    * */
    public void sendMessage(String body, String url, String text, JandiMessage jandiMessage){

        String message = null;
        JandiBody jandiBody= new JandiBody();

        jandiBody.setBody(body, url, text)
                .setConnectColor("#FF0033")
                .addConnectInfo(jandiMessage);

        try{
            message = objectMapper.writeValueAsString(jandiBody);
        }catch(JsonProcessingException e){
            throw new RuntimeException(e);
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Accept", "application/vnd.tosslab.jandi-v2+json");
        httpHeaders.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
        HttpEntity httpEntity = new HttpEntity(message, httpHeaders);
        this.restTemplate.postForEntity(apiUrl, httpEntity, String.class);
    }

}
