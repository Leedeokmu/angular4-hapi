package com.esnotify.utility;

import com.esnotify.enumerate.ESQueryReturnType;
import com.esnotify.enumerate.ESQueryUseFor;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.metrics.avg.Avg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;


/* Elastic Search query를 만들 때
* 유용하게 사용할 수 있는 utility를 구현한 클래스
*
* getFromTime
* getHistogramAgg
* getCountReturn
* */
public class ESQueryBuildUtil {
    private static final Logger logger = LoggerFactory.getLogger(ESQueryBuildUtil.class);
    /* Elastiz1cSearch에서 Query Aggregation을 생성할 때
    * Histogram 생성에서 epoch time을 얻기 위한 static method
    * LocalDateTime 클래스를 이용하여 Asia/Tokyo zone의 시간을 기준으로
    * epoch time을 얻어옵니다.
    */
    public static long getRange(Integer hour, Integer minute, Integer second){
        long range = LocalTime.of(hour, minute, second).toNanoOfDay();

        return range / (1000 * 1000);
    }

    // HistogramBuilder scaffoding
    public static DateHistogramBuilder getHistogramAgg(Long now, Long from, ESQueryUseFor useFor){
        DateHistogramInterval tmpInterval =  null;

        if(useFor == ESQueryUseFor.GRAPH){
            tmpInterval = DateHistogramInterval.seconds(5);
        }else if(useFor == ESQueryUseFor.SCHEDULER){
            tmpInterval = DateHistogramInterval.minutes(10);
        }

        return AggregationBuilders
                .dateHistogram("1")
                .field("@timestamp")
                .interval(tmpInterval)
                .timeZone("Asia/Tokyo")
                .minDocCount(1)
                .extendedBounds(from, now);
    }
    /*
    * plural 값을 얻을 것인지 singular 값을 얻을 것인지
    * time range의 격차를 판단하여(if interval > 15m)
    * return할 type을 계산
    *
    * @parameter : agg, from, now
    * @return : double
    * */
    public static double getCountReturn(Histogram agg, long range, boolean isRes){
        long pluralStd = ESQueryBuildUtil.getRange(0,10,0);
        boolean isSingular = (pluralStd >= range);
        logger.info("isSingular : " + isSingular);

        double result = 0;
        Avg avg;
        if(isSingular == true){
            if(isRes){
                Histogram.Bucket bucket = agg.getBuckets().get(0);
                avg = bucket.getAggregations().get("2");
                result = avg.getValue();
            }else{
                result = agg.getBuckets().get(0).getDocCount();
            }
        }else if(isSingular == false){
            if(isRes){
                for(Histogram.Bucket bucket: agg.getBuckets()){
                    avg = bucket.getAggregations().get("2");
                    result += avg.getValue();
                }
            }else{
                for(Histogram.Bucket bucket: agg.getBuckets()){
                    result += bucket.getDocCount();
                }
            }
            result /= agg.getBuckets().size();
        }
        return result;
    }
}