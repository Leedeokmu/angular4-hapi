package com.esnotify.utility;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/*
* Value를 저장하는 클래스
* static 변수로부터 값을 얻어옴
* config.properties로부터 value를 입력받아
* bean 생성 시 static 변수로 값을 전달
* */
@Component
public class ValueGetterUtil {
    public static Double RESPONSE_TIME_THRESHOLD;
    public static String apiService;
    public static String mobileService;
    public static String dealinfoService;
    public static String apiNginxIndex;
    public static String apiTomcatIndex;
    public static String uiNginxIndex;
    public static String uiTomcatIndex;
    public static String wwwIndex;
    public static String apiUrl;
    public static String timezone;

    @Value("#{config['es.threshold.response-time ']}")
    public void setResponseTimeThreshold(Double responseTimeThreshold) { this.RESPONSE_TIME_THRESHOLD = responseTimeThreshold; }

    @Value("#{config['es.tmon.api-service']}")
    public void setApiService(String apiService) {
        this.apiService = apiService;
    }

    @Value("#{config['es.tmon.mobile-service']}")
    public void setMobileService(String mobileService) {
        this.mobileService = mobileService;
    }

    @Value("#{config['es.tmon.dealinfo-service']}")
    public void setDealinfoService(String dealinfoService) {
        this.dealinfoService = dealinfoService;
    }

    @Value("#{config['es.tmon.api-nginx-index']}")
    public void setApiNginxIndex(String apiNginxIndex) {
        this.apiNginxIndex = apiNginxIndex;
    }

    @Value("#{config['es.tmon.api-tomcat-index']}")
    public void setApiTomcatIndex(String apiTomcatIndex) {
        this.apiTomcatIndex = apiTomcatIndex;
    }

    @Value("#{config['es.tmon.ui-nginx-index']}")
    public void setUiNginxIndex(String uiNginxIndex) {
        this.uiNginxIndex = uiNginxIndex;
    }

    @Value("#{config['es.tmon.ui-tomcat-index']}")
    public void setUiTomcatIndex(String uiTomcatIndex) {
        this.uiTomcatIndex = uiTomcatIndex;
    }

    @Value("#{config['es.tmon.www-index']}")
    public void setWwwIndex(String wwwIndex) {
        this.wwwIndex = wwwIndex;
    }

    @Value("#{config['jandi.api-url']}")
    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    @Value("#{config['es.tmon.time-zone']}")
    public void setTimezone(String timezone) { ValueGetterUtil.timezone = timezone; }
}