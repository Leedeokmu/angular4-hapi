package com.esnotify.service;

import com.esnotify.dto.JandiMessage;
import com.esnotify.enumerate.ESQueryType;
import com.esnotify.enumerate.ESQueryUseFor;
import com.esnotify.repository.BaseQuery;
import com.esnotify.repository.esquery.*;
import com.esnotify.utility.ESQueryBuildUtil;
import com.esnotify.utility.JandiMsgSenderUtil;
import com.esnotify.utility.ValueGetterUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.EnumMap;
import java.util.Map;

@Service
public class ESIndexService {
    private  final Logger logger = LoggerFactory.getLogger(ESIndexService.class);

    /*
    * @Autowired 될 클래스 객체 선언
    * */
    private BaseQuery mapiTomcatLogCount;
    private BaseQuery mGatewayTomcatLogCountTLE;
    private BaseQuery dealinfoAPITomcatLogCount;
    private BaseQuery mapiResponseTime;
    private BaseQuery mGatewayResponseTime;
    private BaseQuery dealinfoAPIResponseTime;

    private Map<ESQueryType, Double> thresholds;
    private static Map<ESQueryType, BaseQuery> queryMap;

    /*
    * constructor 내에서 Autowire 수행
    * */
    @Autowired
    public ESIndexService(MAPITomcatLogCountQuery mapiTomcatLogCount, MGatewayTomcatLogCountTLEQuery mGatewayTomcatLogCountTLE
            , DealinfoAPITomcatLogCountQuery dealinfoAPITomcatLogCount, MAPIResponseTimeQuery mapiResponseTime
            , MGatewayResponseTimeQuery mGatewayResponseTime, DealinfoAPIResponseTimeQuery dealinfoAPIResponseTime){
        thresholds = new EnumMap<>(ESQueryType.class);
        for (ESQueryType queryType : ESQueryType.values()) {
            if(queryType.toString().contains("ResponseTime")){
                thresholds.put(queryType, 0.1);
            }else{
                thresholds.put(queryType, 0.0);
            }
        }
        this.dealinfoAPITomcatLogCount = dealinfoAPITomcatLogCount;
        this.mGatewayTomcatLogCountTLE = mGatewayTomcatLogCountTLE;
        this.mapiTomcatLogCount = mapiTomcatLogCount;
        this.mapiResponseTime = mapiResponseTime;
        this.mGatewayResponseTime = mGatewayResponseTime;
        this.dealinfoAPIResponseTime = dealinfoAPIResponseTime;

        queryMap = new EnumMap<>(ESQueryType.class);
        {
            queryMap.put(ESQueryType.MAPITomcatLogCount, mapiTomcatLogCount);
//            queryMap.put(ESQueryType.MGatewayTomcatLogCountTLE, mGatewayTomcatLogCountTLE);
//            queryMap.put(ESQueryType.DealinfoAPITomcatLogCount, dealinfoAPITomcatLogCount);
//            queryMap.put(ESQueryType.MAPIResponseTime, mapiResponseTime);
//            queryMap.put(ESQueryType.MGatewayResponseTime, mGatewayResponseTime);
//            queryMap.put(ESQueryType.DealinfoAPIResponseTime, dealinfoAPIResponseTime);
        }
    }

    /*
    * 10분 마다 한번씩 query를 실행하여 JANDI 메신져로
    * push 해주는 기능을 하는 함수입니다.
    *
    * query 실행 ->
    * threshold와 비교 ->
    * bool 배열에 결과를 담음 ->
    * 비교를 마친 후 warning할 부분을 한꺼번에 push
    * */
    public void lookupRadicalChange() throws Exception {
        logger.info("lookupRadicalChange() JOB START =======================================");

        JandiMsgSenderUtil sender = new JandiMsgSenderUtil(ValueGetterUtil.apiUrl);
        JandiMessage jandiMessage = null;

        Map<ESQueryType, Boolean> areResultsAbnormal = new EnumMap<>(ESQueryType.class);


        long range = ESQueryBuildUtil.getRange(0,10,0);

        queryMap.entrySet().parallelStream().forEach(query -> {
            ESQueryType queryType = query.getKey();
            double tmp;
            try {
                tmp = queryType.executeQuery(queryMap.get(queryType), ESQueryUseFor.SCHEDULER, range);
                boolean isAbnormal =  (thresholds.get(queryType) < tmp);
                areResultsAbnormal.put(queryType, isAbnormal);

                logger.info("Threshold : " + thresholds.get(queryType) + " " + queryType + " value : " + tmp);
            } catch (Exception e) {
                logger.error(queryType.toString() + " has error implementing query : " + e.getMessage());
            }
        });

        StringBuilder sb = new StringBuilder();
        for(ESQueryType queryType: areResultsAbnormal.keySet()){
            if(areResultsAbnormal.get(queryType)){
                sb.append(queryType.toString() + " value has been over threshold.\n");
            }
        }
        if(sb.length() > 0){
            sender.sendMessage("NotifierForEs", "http://warning.com", " Server Warning"
                    ,new JandiMessage("Warning", sb.toString()));
        }
        logger.info("lookupRadicalChange() JOB END =======================================");
    }
    /*
    * threshold를 설정해 주는 함수입니다. 총 세 종류의 threshold를 가지며 종류는
    * 1. access count(Not applied)
    * 2. tomcat error count
    * 3. response time
    * 와 같습니다.
    *
    * threshold를 얻어내기 위한 queryMap을 선언 후 실행할 함수를 등록 ->
    * parameter 셋 후 실행하여 threshold를 얻어내고 추가적으로 thresholdMap 에 저장 ->
    * 이후로는 해당 값을 새로 갱신
    * */
    public void changeThreshold() throws Exception {
        logger.info("changeThreshold() JOB START =======================================");

        long range = ESQueryBuildUtil.getRange(12,0,0);
        queryMap.entrySet().parallelStream().forEach(query -> {
            ESQueryType queryType = query.getKey();
            try {
                thresholds.put(queryType, queryType.executeQuery(queryMap.get(queryType), ESQueryUseFor.SCHEDULER, range)*2);
            } catch (Exception e) {
                logger.error(queryType.toString() + " has error implementing query : " + e.getMessage());
                e.printStackTrace();
            }
        });

        for(ESQueryType queryType: queryMap.keySet()){
            logger.info(queryType.toString() + " Threshold : " + thresholds.get(queryType));
        }
        logger.info("changeThreshold() JOB END =======================================");
    }
}
