package com.esnotify.repository;

import com.esnotify.dto.ESQueryParams;
import com.esnotify.enumerate.ESQueryUseFor;

/*
* 모든 query에 대한 interface
* */
public interface BaseQuery {
    public double getQueryResult(ESQueryParams src, ESQueryUseFor useFor) throws Exception;
}
