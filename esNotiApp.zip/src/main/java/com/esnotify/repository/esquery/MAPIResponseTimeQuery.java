package com.esnotify.repository.esquery;

import com.esnotify.dto.ESQueryParams;
import com.esnotify.enumerate.ESQueryUseFor;
import com.esnotify.repository.BaseQuery;
import com.esnotify.utility.ESQueryBuildUtil;
import com.esnotify.utility.ValueGetterUtil;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.time.ZoneId;

@Repository

public class MAPIResponseTimeQuery implements BaseQuery {
    private static final Logger logger = LoggerFactory.getLogger(MAPIResponseTimeQuery.class);
    @Autowired
    private Client client;

    public double getQueryResult(ESQueryParams src, ESQueryUseFor useFor) throws Exception {
        logger.info("MAPIResponseTimeQuery(ESQueryParams src, ESQueryUseFor useFor) throws Exception START=================================");
        long now = LocalDateTime.now().atZone(ZoneId.of(ValueGetterUtil.timezone)).toInstant().toEpochMilli();
        long from = now - src.getRange();
        SearchResponse response = client.prepareSearch(src.getIndex())
                .setSize(0)
                .setQuery(QueryBuilders.boolQuery()
                        .must(QueryBuilders.queryStringQuery("*"))
                        .filter(QueryBuilders.boolQuery().must(
                                QueryBuilders.matchQuery("servicename", src.getServiceName())
                        ).must(
                                QueryBuilders.queryStringQuery("*")
                        ).must(
                                QueryBuilders.rangeQuery("@timestamp").gte(from).lte(now)
                        ))
                )
                .addAggregation(
                        ESQueryBuildUtil.getHistogramAgg(now, from, useFor)
                                .subAggregation(AggregationBuilders
                                        .avg("2")
                                        .field("duration")
                                )
                )
                .execute().actionGet();

        Histogram agg = response.getAggregations().get("1");
        logger.info("MAPIResponseTimeQuery(ESQueryParams src, ESQueryUseFor useFor) throws Exception END=================================");
        return ESQueryBuildUtil.getCountReturn(agg, src.getRange(), true);
    }
}
