package com.esnotify;

import com.esnotify.dto.JandiMessage;
import com.esnotify.service.ESIndexService;
import com.esnotify.utility.JandiMsgSenderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class StartUpHandler {
    private static final Logger logger = LoggerFactory.getLogger(StartUpHandler.class);

    @Autowired
    ESIndexService esIndexService;

    @Value("#{config['jandi.api-url']}")
    private String apiUrl;

    /*
    Start up 시 Notification을 주도록  jandi 함수를 호출합니다

    잔디에 App이 Startup 했다고 알림 ->
    전체 threshold를 재설정하여 root 폴더의 특정 폴더 이름에 저장

    @params : none
    @return : void
    */
    public void init() throws Exception {
        logger.info("StartUpHandler : Bootstrap & set initial thresholds.............");

        JandiMsgSenderUtil sender = new JandiMsgSenderUtil(apiUrl);
        JandiMessage message = new JandiMessage("Startup", "App Start up. preparing...");
        sender.sendMessage("Starup Notification","http://", "App is Starting Now", message);
        try {
            esIndexService.changeThreshold();
        } catch (Exception e) {
            logger.info("Exception occurs while init() : " + e.getMessage());
            System.exit(-1);
        }
    }
}
