package com.esnotify.controller;

import com.esnotify.service.ESIndexService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@Controller
@RequestMapping("/information")
public class InformationController {
    private static final Logger logger = LoggerFactory.getLogger(InformationController.class);


    @RequestMapping(value="concept", method= RequestMethod.GET)
    public String concept(Model model) throws Exception{
        logger.info("/concept acceessed =================================");

        model.addAttribute("content", "concept");

        logger.info("/concept exited=================================");
        return "index";
    }










}
