package com.esnotify.schedule;

import com.esnotify.service.ESIndexService;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.quartz.QuartzJobBean;

/*
* 스케쥴 잡 등록의 scalability를 늘리기 위한
* abstract 메서드를 생성하고 job 등록 시 executeJob 메서드만
* 구현하도록 합니다.
* */
public abstract class ScheduleJob extends QuartzJobBean {
    private ApplicationContext ctx;

    private ESIndexService esIndexService;

    public void setEsIndexService(ESIndexService esIndexService) {
        this.esIndexService = esIndexService;
    }

    public ESIndexService getEsIndexService() {
        return esIndexService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) {
        ctx = (ApplicationContext) jobExecutionContext.getJobDetail().getJobDataMap().get("applicationContext");
        if(esIndexService == null) {
            esIndexService = ctx.getBean("esIndexService", ESIndexService.class);
        }
        try {
            executeJob(esIndexService);
        } catch (Exception e) {
            System.out.println("Exception occured ###############");
            e.printStackTrace();
        }
    }
    protected abstract void executeJob(ESIndexService service) throws Exception;
}
