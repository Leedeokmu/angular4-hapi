package com.esnotify.schedule.job;

import com.esnotify.schedule.ScheduleJob;
import com.esnotify.service.ESIndexService;

/**
 * Created by freefly3557 on 2017-07-18.
 */
public class LookupRadicalChangeJob extends ScheduleJob
{
    @Override
    protected void executeJob(ESIndexService service) throws Exception {
        service.lookupRadicalChange();
    }
}
