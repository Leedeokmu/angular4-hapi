package com.esnotify.config;

import com.esnotify.utility.ValueGetterUtil;
import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.net.InetAddress;

/*
* ES 접속을 위한 configuration
* clsutername, host, port를 읽어와서 접속
*
* BEAN으로 등록하여 @autowired해서 사용하도록 구현
*
* */
@Configuration
public class ESConfig {
    @Value("#{config['es.tmon.cluster-name']}")
    private String clusterName;
    @Value("#{config['es.tmon.host']}")
    private String host;
    @Value("#{config['es.tmon.port']}")
    private Integer port;

    @Bean
    public Client client() throws Exception {
        Settings settings = Settings.settingsBuilder()
                .put("cluster.name", clusterName)
                .build();

        return TransportClient.builder().settings(settings).build()
               .addTransportAddress(
                       new InetSocketTransportAddress(InetAddress.getByName(host), port));
    }

    public Client getClient() throws Exception{
        return this.client();
    }
}