package com.esnotify.enumerate;

import com.esnotify.dto.ESQueryParams;
import com.esnotify.repository.BaseQuery;

/*
* 함수 호출의 parameter 정보와 abstract 함수를
* 구현하도록 명명된 enum 클래스
*
* enum 객체 하나마다 구현된 함수를 추가하여
* 같은 로직으로 실행할 abstarction을 구현
* */
public enum ESQueryType {
    /*
    * Tomcat Error Count
    * */
    MAPITomcatLogCount("bapi_tomcat-*", "service_tmon_app_api") {
        @Override
        public double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception {
            ESQueryParams params = new ESQueryParams(this.getIndexName(), this.getServiceName(), range);
            return query.getQueryResult(params, useFor);
        }
    },
    MGatewayTomcatLogCountTLE("ui_tomcat-*", "service_tmon_mobile_api") {
        @Override
        public double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception {
            ESQueryParams params = new ESQueryParams(this.getIndexName(), this.getServiceName(), range);
            return query.getQueryResult(params, useFor);
        }
    },
    DealinfoAPITomcatLogCount("bapi_tomcat-*", "service_tmon_dealinfo_api") {
        @Override
        public double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception {
            ESQueryParams params = new ESQueryParams(this.getIndexName(), this.getServiceName(), range);
            return query.getQueryResult(params, useFor);
        }
    },
    /*
    * Response TIme
    * */
    MAPIResponseTime("bapi_nginx-*", "service_tmon_app_api") {
        @Override
        public double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception {
            ESQueryParams params = new ESQueryParams(this.getIndexName(), this.getServiceName(), range);
            return query.getQueryResult(params, useFor);
        }
    },
    MGatewayResponseTime("ui_nginx-*", "service_tmon_mobile_api") {
        @Override
        public double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception {
            ESQueryParams params = new ESQueryParams(this.getIndexName(), this.getServiceName(), range);
            return query.getQueryResult(params, useFor);
        }
    },
    DealinfoAPIResponseTime("bapi_nginx-*", "service_tmon_dealinfo_api") {
        @Override
        public double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception {
            ESQueryParams params = new ESQueryParams(this.getIndexName(), this.getServiceName(), range);
            return query.getQueryResult(params, useFor);
        }
    };

    private String indexName;
    private String serviceName;

    ESQueryType(String index, String serviceName) {
        this.indexName = index;
        this.serviceName = serviceName;
    }
    public String getServiceName() {
        return serviceName;
    }

    public String getIndexName(){
        return indexName;
    }

    public abstract double executeQuery(BaseQuery query, ESQueryUseFor useFor, long range) throws Exception;
}