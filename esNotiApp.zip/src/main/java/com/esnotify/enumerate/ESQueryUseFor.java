package com.esnotify.enumerate;

/*
* Query의 용도를 알리는 enum class
* */
public enum ESQueryUseFor {
    GRAPH,
    SCHEDULER
}
