package com.esnotify;

import com.esnotify.dto.JandiBody;
import com.esnotify.dto.JandiMessage;
import com.esnotify.utility.ValueGetterUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.mail.smtp.SMTPTransport;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Properties;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = "classpath:/spring/applicationContext.xml")
public class utilTest {
    private static final Logger logger = LoggerFactory.getLogger(utilTest.class);

    @Value("#{config['jandi.api-url']}")
    private String apiUrl;
    private RestTemplate restTemplate;
    private ObjectMapper objectMapper;

    @Before
    public void setUp() throws Exception{

    }

    @Test
    public void jandiTest() throws Exception{
        restTemplate = new RestTemplate();
        objectMapper = new ObjectMapper();

        String message = null;
        JandiBody jandiMessage = new JandiBody();

        jandiMessage.setBody("a","a","asdasdasasasdasda '; ; asdas")
                .setConnectColor("#FF0202")
                .addConnectInfo(new JandiMessage("test1", "test1 description"));

        try{
            message = objectMapper.writeValueAsString(jandiMessage);
        }catch(JsonProcessingException e){
            throw new RuntimeException(e);
        }

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Accept", "application/vnd.tosslab.jandi-v2+json");
        httpHeaders.setContentType(org.springframework.http.MediaType.APPLICATION_JSON);
        HttpEntity<String> httpEntity = new HttpEntity<>(message, httpHeaders);

        this.restTemplate.postForEntity(ValueGetterUtil.apiUrl, httpEntity, String.class);
    }

    public void mailgunTest() throws  Exception{
        Properties props = System.getProperties();
        props.put("mail.smtps.host", "smtp.mailgun.org");

        Session session = Session.getInstance(props, null);
        Message msg = new MimeMessage(session);
        msg.setFrom(new InternetAddress("freefly3557@gmail.com"));

        InternetAddress[] addrs = InternetAddress.parse("freefly3557@gmail.com", false);
        msg.setRecipients(Message.RecipientType.TO, addrs);

        msg.setSubject("Hello");
        msg.setText("Testing some Mailgun awesomness");
        msg.setSentDate(new Date());

        SMTPTransport t =
                (SMTPTransport) session.getTransport("smtps");
        t.connect("smtp.mailgun.com", "postmaster@sandboxdfaff11bb0054ecfb6f415664796b50b.mailgun.org", "e4301110119388642842b71d1f476cf3");
        t.sendMessage(msg, msg.getAllRecipients());

        System.out.println("Response: " + t.getLastServerResponse());

        t.close();
    }

    public void monitorTest() throws Exception{
        ApplicationContext ctx = new ClassPathXmlApplicationContext("spring/applicationContext.xml");
        System.out.println("Quartz Start!!");
    }

    @Test
    public void dummyTest() throws InterruptedException {
        Thread.sleep(10000);
    }

    @Test
    public void localDateTimeTest() throws Exception{
//        long now = LocalTime.of(12,0).toNanoOfDay() /  (1000 * 1000);
        long now = LocalTime.of(12,0).toNanoOfDay();
        logger.info(String.valueOf(now));
    }
}
