package com.esnotify;

import com.esnotify.dto.ESQueryParams;
import com.esnotify.enumerate.ESQueryUseFor;
import com.esnotify.repository.esquery.DealinfoAPITomcatLogCountQuery;
import com.esnotify.repository.esquery.MAPITomcatLogCountQuery;
import com.esnotify.repository.esquery.MGatewayTomcatLogCountTLEQuery;
import com.esnotify.service.ESIndexService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.time.ZoneId;


@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(locations = "classpath:/spring/applicationContext.xml")
public class esTest {
    private static final Logger logger = LoggerFactory.getLogger(esTest.class);

    @Autowired
    MAPITomcatLogCountQuery mapiTomcatLogCountQuery;
    @Autowired
    MGatewayTomcatLogCountTLEQuery mapiTomcatLogCountTLEQuery;
    @Autowired
    DealinfoAPITomcatLogCountQuery dealinfoAPITomcatLogCountQuery;

    @Autowired
    private ESIndexService esIndexService;

    @Value("#{config['jandi.api-url']}")
    private String apiUrl;
    private RestTemplate restTemplate;
    private ObjectMapper objectMapper;

    private long now;
    private long from;

    @Before
    public void setUp() throws Exception{
        now = LocalDateTime.now().atZone(ZoneId.of("Asia/Tokyo")).toInstant().toEpochMilli();
        from = LocalDateTime.now().minusHours(2).atZone(ZoneId.of("Asia/Tokyo")).toInstant().toEpochMilli();
    }

    public void mobileAPIAccessLogCountTest() throws Exception{
        ESQueryParams src = new ESQueryParams("service_tmon_app_api", "bapi_nginx-*",
                LocalDateTime.of(0,0,0,0,10,0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());

        logger.info(String.valueOf(mapiTomcatLogCountQuery.getQueryResult(src, ESQueryUseFor.SCHEDULER)));
    }

//    public void mobileAPITomcatLogCountTest() throws  Exception{
//        ESQueryParams src = new ESQueryParams("service_tmon_app_api", "bapi_tomcat-*", 1500528887245L, 1500485687245L);
//        Long tmp = esIndexRepository.getMAPITomcatLogCount(src, ESQueryReturnType.Plural);
//
//        System.out.println(tmp);
//    }
//
//    public void mobileAPIResponseTimeTest() throws  Exception{
//        ESQueryParams src = new ESQueryParams("service_tmon_app_aPpi", "bapi_nginx-*", 1500532546097L, 1500489346097L);
//        double tmp  = esIndexRepository.getMAPIResponseTime(src, ESQueryReturnType.Plural);
//
//        System.out.println(tmp);
//    }

//    public void mobileAPIMaxResponseTimeTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getMAPIMaxResponseTime("bapi_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileGatewayAccedssCountTotalTest() throws Exception{
//        ArrayList<String> list = esIndexRepository.getMGatewayAccessCount("ui_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileAPITomcatLogCounteTLETest() throws Exception{
//        ArrayList<String> list = esIndexRepository.getMAPITomcatLogCounteTLE("ui_tomcat-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileGatewayResponseTimeTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getMGatewayResponseTime("ui_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileGatewayMaxResponseTimeTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getMGatewayMaxResponseTime( "ui_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileAPIAccessCountHistogramTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getMAPIAccessCountHistogram( "www-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileAPITodayPickAccessCountTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getMAPITodayPickAccessCount( "bapi_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void mobileGatewayTodayPickAPIAccessCount() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getMGatewayTodayPickAPIAccessCount( "ui_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void dealinfoAPIAccessCountTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getDealinfoAPIAccessCount( "bapi_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void dealinfoAPITomcatLogCountTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getDealinfoAPITomcatLogCount( "bapi_tomcat-*");
//
//        System.out.println(list);
//    }
//
//    public void dealinfoAPIResponseTimeTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getDealinfoAPIResponseTime( "bapi_nginx-*");
//
//        System.out.println(list);
//    }
//
//    public void dealinfoAPIMaxResponseTimeTest() throws  Exception{
//        ArrayList<String> list = esIndexRepository.getDealinfoAPIMaxResponseTime( "bapi_nginx-*");
//
//        System.out.println(list);
//    }

    @Test
    public void esServiceTest() throws Exception{
        esIndexService.changeThreshold();
        esIndexService.lookupRadicalChange();
    }
}
